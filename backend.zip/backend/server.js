const express = require('express');
const cors = require('cors');
const db = require('./db');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// GET all exhibits
app.get('/api/exhibits', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM exhibits ORDER BY id DESC');
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// GET single exhibit
app.get('/api/exhibits/:id', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM exhibits WHERE id = ?', [req.params.id]);
        if (rows.length === 0) {
            return res.status(404).json({ error: 'Exhibit not found' });
        }
        res.json(rows[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST create exhibit
app.post('/api/exhibits', async (req, res) => {
    try {
        const { exhibit_title, artist_name, description, start_date, end_date, location } = req.body;
        const [result] = await db.query(
            'INSERT INTO exhibits (exhibit_title, artist_name, description, start_date, end_date, location) VALUES (?, ?, ?, ?, ?, ?)',
            [exhibit_title, artist_name, description, start_date, end_date, location]
        );
        res.status(201).json({ id: result.insertId, message: 'Exhibit created successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// PUT update exhibit
app.put('/api/exhibits/:id', async (req, res) => {
    try {
        const { exhibit_title, artist_name, description, start_date, end_date, location } = req.body;
        const [result] = await db.query(
            'UPDATE exhibits SET exhibit_title = ?, artist_name = ?, description = ?, start_date = ?, end_date = ?, location = ? WHERE id = ?',
            [exhibit_title, artist_name, description, start_date, end_date, location, req.params.id]
        );
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Exhibit not found' });
        }
        res.json({ message: 'Exhibit updated successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// DELETE exhibit
app.delete('/api/exhibits/:id', async (req, res) => {
    try {
        const [result] = await db.query('DELETE FROM exhibits WHERE id = ?', [req.params.id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Exhibit not found' });
        }
        res.json({ message: 'Exhibit deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.listen(PORT, () => {
    console.log('Server running on http://localhost:' + PORT);
})